///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  Modified by Hanna Alemu for the CS-330 final project, Oct. 2026
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;		// start with an empty texture list
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free the textures
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

// top of the table (legs 1.6 + top 0.48), objects on the table start here
static const float TABLE_TOP_Y = 1.6f + 0.48f;


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();				// floor, wall
	m_basicMeshes->LoadCylinderMesh();			// tabletop, rug, necks
	m_basicMeshes->LoadBoxMesh();				// legs, books, branches
	m_basicMeshes->LoadSphereMesh();			// pot, bowl
	m_basicMeshes->LoadTaperedCylinderMesh();	// vase
	m_basicMeshes->LoadPyramid4Mesh();			// blossoms

	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads all the texture images (1024 x 1024, CC0
 *  textures from Poly Haven).
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("textures/oak_wood_planks.jpg", "oakTop");
	CreateGLTexture("textures/oak_veneer_05.jpg", "oakEdge");
	CreateGLTexture("textures/rosewood_veneer1.jpg", "rosewood");
	CreateGLTexture("textures/interior_tiles.jpg", "floorTile");
	CreateGLTexture("textures/linoleum_brown.jpg", "clay");
	CreateGLTexture("textures/curly_teddy_natural.jpg", "rug");
	CreateGLTexture("textures/long_white_tiles.jpg", "wallTile");

	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Materials for each surface.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// shiny floor tile
	OBJECT_MATERIAL tileMaterial;
	tileMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	tileMaterial.ambientStrength = 0.05f;
	tileMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	tileMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	tileMaterial.shininess = 1.0f;
	tileMaterial.tag = "tile";
	m_objectMaterials.push_back(tileMaterial);

	// oak top, a little shine
	OBJECT_MATERIAL oakMaterial;
	oakMaterial.ambientColor = glm::vec3(0.25f, 0.2f, 0.15f);
	oakMaterial.ambientStrength = 0.05f;
	oakMaterial.diffuseColor = glm::vec3(0.55f, 0.5f, 0.45f);
	oakMaterial.specularColor = glm::vec3(0.4f, 0.35f, 0.3f);
	oakMaterial.shininess = 0.4f;
	oakMaterial.tag = "oak";
	m_objectMaterials.push_back(oakMaterial);

	// matte wood legs
	OBJECT_MATERIAL walnutMaterial;
	walnutMaterial.ambientColor = glm::vec3(0.2f, 0.15f, 0.1f);
	walnutMaterial.ambientStrength = 0.05f;
	walnutMaterial.diffuseColor = glm::vec3(0.6f, 0.55f, 0.5f);
	walnutMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	walnutMaterial.shininess = 0.15f;
	walnutMaterial.tag = "walnut";
	m_objectMaterials.push_back(walnutMaterial);

	// rough clay, almost no shine
	OBJECT_MATERIAL clayMaterial;
	clayMaterial.ambientColor = glm::vec3(0.25f, 0.15f, 0.1f);
	clayMaterial.ambientStrength = 0.05f;
	clayMaterial.diffuseColor = glm::vec3(0.55f, 0.5f, 0.45f);
	clayMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	clayMaterial.shininess = 0.05f;
	clayMaterial.tag = "clay";
	m_objectMaterials.push_back(clayMaterial);

	// glossy ceramic for the vase and bowl
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	ceramicMaterial.ambientStrength = 0.05f;
	ceramicMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	ceramicMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	ceramicMaterial.shininess = 1.0f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	// matte for books, rug, wall, branches
	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	matteMaterial.ambientStrength = 0.05f;
	matteMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	matteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.shininess = 0.05f;
	matteMaterial.tag = "matte";
	m_objectMaterials.push_back(matteMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Four point lights for the room.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// light 0 - warm amber lamp above the table (colored light)
	// the shader tints with the ambient color, so it's set higher
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 10.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.2f, 0.12f, 0.04f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 0.8f, 0.55f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 0.8f, 0.55f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.8f);

	// light 1 - cool window light from the left
	m_pShaderManager->setVec3Value("lightSources[1].position", -12.0f, 6.0f, 4.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.0f, 0.02f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.6f, 0.75f, 1.0f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.6f, 0.75f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

	// light 2 - back left lamp, lights the back and shines on the floor
	m_pShaderManager->setVec3Value("lightSources[2].position", -10.0f, 4.0f, -8.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.6f, 0.55f, 0.5f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.6f, 0.55f, 0.5f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 1.0f);

	// light 3 - below the floor, lights the underside of the tabletop
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, -1000.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);
}

/***********************************************************
 *  SetTexturedSurface()
 *
 *  Sets texture, UV scale, and material in one call.
 ***********************************************************/
void SceneManager::SetTexturedSurface(
	std::string textureTag,
	float uScale,
	float vScale,
	std::string materialTag)
{
	SetShaderTexture(textureTag);
	SetTextureUVScale(uScale, vScale);
	SetShaderMaterial(materialTag);
}

/***********************************************************
 *  SetColoredSurface()
 *
 *  Sets a flat color and material in one call.
 ***********************************************************/
void SceneManager::SetColoredSurface(
	glm::vec3 color,
	std::string materialTag)
{
	SetShaderColor(color.r, color.g, color.b, 1.0f);
	SetShaderMaterial(materialTag);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderFloor();
	RenderBackWall();
	RenderRug();
	RenderCoffeeTable();

	// placed to match the photo
	RenderClayPot(glm::vec3(-1.1f, TABLE_TOP_Y, 0.1f));
	RenderBlossomVase(glm::vec3(0.5f, TABLE_TOP_Y, -0.9f));

	// bowl sits on top of the books
	glm::vec3 bookPosition = glm::vec3(0.9f, TABLE_TOP_Y, 0.9f);
	float bookStackHeight = RenderBookStack(bookPosition);
	RenderGlazedBowl(bookPosition + glm::vec3(0.0f, bookStackHeight, 0.0f));
}

/***********************************************************
 *  RenderFloor()
 *
 *  Tiled floor plane.
 ***********************************************************/
void SceneManager::RenderFloor()
{
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 10.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));

	// tiling - repeat the tile image 6 x 3
	SetTexturedSurface("floorTile", 6.0f, 3.0f, "tile");
	m_basicMeshes->DrawPlaneMesh();

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderBackWall()
 *
 *  Tiled wall behind the table.
 ***********************************************************/
void SceneManager::RenderBackWall()
{
	// rotated 90 on X to stand it up
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 5.0f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 5.0f, -10.0f));

	SetTexturedSurface("wallTile", 4.0f, 1.0f, "matte");
	m_basicMeshes->DrawPlaneMesh();

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderRug()
 *
 *  Round rug, a flat cylinder.
 ***********************************************************/
void SceneManager::RenderRug()
{
	SetTransformations(
		glm::vec3(5.0f, 0.04f, 5.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));

	SetTexturedSurface("rug", 3.0f, 3.0f, "matte");
	m_basicMeshes->DrawCylinderMesh(true, false, true);

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderCoffeeTable()
 *
 *  Cylinder top and two crossed boxes for the base.
 ***********************************************************/
void SceneManager::RenderCoffeeTable()
{
	// leg 1
	SetTransformations(
		glm::vec3(3.04f, 1.6f, 0.56f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.8f, 0.0f));

	SetTexturedSurface("rosewood", 1.0f, 1.0f, "walnut");
	m_basicMeshes->DrawBoxMesh();

	// leg 2, turned 90 to make the plus shape
	SetTransformations(
		glm::vec3(3.04f, 1.6f, 0.56f),
		0.0f, 90.0f, 0.0f,
		glm::vec3(0.0f, 0.8f, 0.0f));

	SetTexturedSurface("rosewood", 1.0f, 1.0f, "walnut");
	m_basicMeshes->DrawBoxMesh();

	// tabletop on top of the legs
	SetTransformations(
		glm::vec3(2.72f, 0.48f, 2.72f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 1.6f, 0.0f));

	// top face
	SetTexturedSurface("oakTop", 1.0f, 1.0f, "oak");
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// rim and bottom, repeated 3x around so it doesn't stretch
	SetTexturedSurface("oakEdge", 3.0f, 1.0f, "oak");
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderClayPot()
 *
 *  Sphere body, cylinder neck and lip.
 ***********************************************************/
void SceneManager::RenderClayPot(glm::vec3 basePosition)
{
	// body
	SetTransformations(
		glm::vec3(0.7f, 0.55f, 0.7f),
		0.0f, 0.0f, 0.0f,
		basePosition + glm::vec3(0.0f, 0.55f, 0.0f));

	SetTexturedSurface("clay", 2.0f, 1.0f, "clay");
	m_basicMeshes->DrawSphereMesh();

	// neck
	SetTransformations(
		glm::vec3(0.38f, 0.22f, 0.38f),
		0.0f, 0.0f, 0.0f,
		basePosition + glm::vec3(0.0f, 0.97f, 0.0f));

	SetTexturedSurface("clay", 2.0f, 1.0f, "clay");
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	// lip
	SetTransformations(
		glm::vec3(0.44f, 0.06f, 0.44f),
		0.0f, 0.0f, 0.0f,
		basePosition + glm::vec3(0.0f, 1.19f, 0.0f));

	SetTexturedSurface("clay", 2.0f, 1.0f, "clay");
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderBlossomVase()
 *
 *  Tapered cylinder vase with three branches.
 ***********************************************************/
void SceneManager::RenderBlossomVase(glm::vec3 basePosition)
{
	// body
	SetTransformations(
		glm::vec3(0.45f, 1.0f, 0.45f),
		0.0f, 0.0f, 0.0f,
		basePosition);

	SetColoredSurface(glm::vec3(0.9f, 0.87f, 0.8f), "ceramic");	// cream
	m_basicMeshes->DrawTaperedCylinderMesh(false, true, true);

	// neck
	SetTransformations(
		glm::vec3(0.17f, 0.45f, 0.17f),
		0.0f, 0.0f, 0.0f,
		basePosition + glm::vec3(0.0f, 1.0f, 0.0f));

	SetColoredSurface(glm::vec3(0.9f, 0.87f, 0.8f), "ceramic");
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	// branches leaning different ways
	glm::vec3 branchStart = basePosition + glm::vec3(0.0f, 1.2f, 0.0f);
	RenderBlossomBranch(branchStart, 2.2f, 18.0f, -8.0f);
	RenderBlossomBranch(branchStart, 1.8f, -25.0f, 10.0f);
	RenderBlossomBranch(branchStart, 1.5f, 5.0f, 22.0f);
}

/***********************************************************
 *  RenderBlossomBranch()
 *
 *  One branch with three blossoms. zTilt/xTilt are the
 *  lean in degrees.
 ***********************************************************/
void SceneManager::RenderBlossomBranch(
	glm::vec3 start,
	float length,
	float zTilt,
	float xTilt)
{
	// direction the branch points after tilting
	glm::mat4 rotation =
		glm::rotate(glm::radians(xTilt), glm::vec3(1.0f, 0.0f, 0.0f)) *
		glm::rotate(glm::radians(zTilt), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::vec3 direction = glm::vec3(rotation * glm::vec4(0.0f, 1.0f, 0.0f, 0.0f));

	// box is centered, so shift it half its length
	SetTransformations(
		glm::vec3(0.04f, length, 0.04f),
		xTilt, 0.0f, zTilt,
		start + direction * (length * 0.5f));

	SetColoredSurface(glm::vec3(0.35f, 0.25f, 0.18f), "matte");	// brown
	m_basicMeshes->DrawBoxMesh();

	// each blossom is two pyramids, one flipped
	const float blossomSpots[3] = { 0.55f, 0.78f, 1.0f };
	for (int i = 0; i < 3; i++)
	{
		glm::vec3 blossomPosition = start + direction * (length * blossomSpots[i]);
		float spin = 30.0f * i;

		SetColoredSurface(glm::vec3(0.96f, 0.95f, 0.91f), "matte");	// off-white

		SetTransformations(
			glm::vec3(0.16f, 0.12f, 0.16f),
			0.0f, spin, 0.0f,
			blossomPosition);
		m_basicMeshes->DrawPyramid4Mesh();

		SetTransformations(
			glm::vec3(0.16f, 0.12f, 0.16f),
			180.0f, spin, 0.0f,
			blossomPosition);
		m_basicMeshes->DrawPyramid4Mesh();
	}
}

/***********************************************************
 *  RenderBookStack()
 *
 *  Two stacked books. Returns the stack height.
 ***********************************************************/
float SceneManager::RenderBookStack(glm::vec3 basePosition)
{
	const int BOOK_COUNT = 2;

	const glm::vec3 bookSize[BOOK_COUNT] = {
		glm::vec3(1.3f, 0.18f, 0.95f),
		glm::vec3(1.2f, 0.16f, 0.9f) };
	const float bookTurn[BOOK_COUNT] = { 15.0f, 8.0f };
	const glm::vec3 bookColor[BOOK_COUNT] = {
		glm::vec3(0.32f, 0.3f, 0.3f),		// charcoal
		glm::vec3(0.88f, 0.78f, 0.68f) };	// cream

	float stackHeight = 0.0f;
	for (int i = 0; i < BOOK_COUNT; i++)
	{
		SetTransformations(
			bookSize[i],
			0.0f, bookTurn[i], 0.0f,
			basePosition + glm::vec3(0.0f, stackHeight + bookSize[i].y * 0.5f, 0.0f));

		SetColoredSurface(bookColor[i], "matte");
		m_basicMeshes->DrawBoxMesh();

		stackHeight += bookSize[i].y;
	}

	return(stackHeight);
}

/***********************************************************
 *  RenderGlazedBowl()
 *
 *  Half sphere bowl on a cylinder foot.
 ***********************************************************/
void SceneManager::RenderGlazedBowl(glm::vec3 basePosition)
{
	// foot
	SetTransformations(
		glm::vec3(0.22f, 0.05f, 0.22f),
		0.0f, 0.0f, 0.0f,
		basePosition);

	SetColoredSurface(glm::vec3(0.55f, 0.3f, 0.2f), "ceramic");	// reddish brown
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// bowl, flipped so it opens up
	SetTransformations(
		glm::vec3(0.5f, 0.3f, 0.5f),
		180.0f, 0.0f, 0.0f,
		basePosition + glm::vec3(0.0f, 0.35f, 0.0f));

	SetColoredSurface(glm::vec3(0.55f, 0.3f, 0.2f), "ceramic");
	m_basicMeshes->DrawHalfSphereMesh();
}
